(function (root) {
  'use strict';
  const WINDOW_MS = 30_000;
  const EPSILON = 1e-8;
  const validSymbol = s => typeof s === 'string' && /^[A-Z0-9_]{2,60}$/.test(s);
  function marketOf(tick, fallback) {
    if (Number(tick.st) === 1) return 'UM';
    if (Number(tick.st) === 2) return 'CM';
    return fallback;
  }
  class RadarEngine {
    constructor(threshold = 2) {
      this.rows = new Map();
      this.threshold = threshold;
      this.sequence = 0;
      this.setThreshold(threshold);
    }
    setThreshold(value) {
      const n = Number(value);
      if (!Number.isFinite(n) || n < 0.1 || n > 100) throw new RangeError('Ngưỡng phải từ 0,1% đến 100%.');
      this.threshold = n;
      for (const row of this.rows.values()) row.alertSide = 0;
    }
    resetMarket(market) {
      for (const [key, row] of this.rows) if (row.market === market) this.rows.delete(key);
    }
    remove(key) { this.rows.delete(key); }
    ingest(tick, fallbackMarket) {
      const price = Number(tick.c), time = Number(tick.E);
      if (!validSymbol(tick.s) || !(price > 0) || !Number.isFinite(price) || !Number.isFinite(time) || time < 0) return false;
      const market = marketOf(tick, fallbackMarket);
      if (market !== 'UM' && market !== 'CM') return false;
      const key = market + ':' + tick.s;
      let row = this.rows.get(key);
      if (!row) {
        row = {key, market, symbol: tick.s, firstTime: time, lastTime: time, price,
          samples: [], alertSide: 0, base: null, pct: null, progress: 0, ready: false};
        this.rows.set(key, row);
      } else if (time <= row.lastTime) {
        return false; // Duplicate or out-of-order packet, including merged feeds.
      }
      row.price = price;
      row.lastTime = time;
      row.samples.push({time, price});
      this.prune(row, time - WINDOW_MS);
      return true;
    }
    prune(row, target) {
      // Preserve the last observed price at/before the left edge, even if
      // unchanged tickers were omitted from the all-market delta stream.
      let n = 0;
      while (n + 1 < row.samples.length && row.samples[n + 1].time <= target) n++;
      if (n) row.samples.splice(0, n);
    }
    evaluate(market, now, healthy = true) {
      const alerts = [];
      for (const row of this.rows.values()) {
        if (row.market !== market) continue;
        if (!healthy || !Number.isFinite(now)) {
          row.ready = false; row.pct = null; row.base = null; row.progress = 0;
          continue;
        }
        row.progress = Math.min(1, Math.max(0, (now - row.firstTime) / WINDOW_MS));
        const target = now - WINDOW_MS;
        this.prune(row, target);
        const anchor = row.samples[0];
        row.ready = row.progress === 1 && anchor.time <= target && row.lastTime <= now;
        if (!row.ready) { row.pct = null; row.base = null; continue; }
        row.base = anchor.price;
        row.pct = (row.price - anchor.price) / anchor.price * 100;
        const side = row.pct < 0 ? -1 : 1;
        const magnitude = Math.abs(row.pct);
        // Re-arm below 80% of the threshold to avoid repeated boundary noise.
        if (magnitude < this.threshold * 0.8) row.alertSide = 0;
        if (magnitude + EPSILON >= this.threshold && row.alertSide !== side) {
          row.alertSide = side;
          alerts.push({id: ++this.sequence, key: row.key, market: row.market,
            symbol: row.symbol, pct: row.pct, price: row.price, base: row.base,
            time: now, threshold: this.threshold});
        }
      }
      return alerts;
    }
  }
  const api = {RadarEngine, WINDOW_MS, marketOf, validSymbol};
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.FuturesCore = api;
})(globalThis);
