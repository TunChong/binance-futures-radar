(function () {
  'use strict';
  const {RadarEngine, marketOf, validSymbol} = FuturesCore;
  const $ = id => document.getElementById(id);
  const names = {UM: 'USDⓈ-M', CM: 'COIN-M'};
  const STORAGE_KEY = 'futures-radar-threshold-v1';
  let saved = 2;
  try { const v = Number(localStorage.getItem(STORAGE_KEY)); if (v >= 0.1 && v <= 100) saved = v; } catch (_) {}
  const engine = new RadarEngine(saved);
  const feeds = [
    {market:'UM', rest:'https://fapi.binance.com/fapi/v1/exchangeInfo', endpoints:[
      {url:'wss://fstream.binance.com/market/ws/!miniTicker@arr', fallback:'UM'},
      {url:'wss://fstream.binance.com/ws/!miniTicker@arr', fallback:'UM'}]},
    {market:'CM', rest:'https://dapi.binance.com/dapi/v1/exchangeInfo', endpoints:[
      {url:'wss://dstream.binance.com/ws/!miniTicker@arr', fallback:'CM'},
      {url:'wss://dstream.binance.com/market/ws/!miniTicker@arr', fallback:'CM'},
      {url:'wss://fstream.binance.com/market/ws/!miniTicker@arr', fallback:'UM'}]}
  ].map(config => ({...config, ws:null, timer:0, index:0, failures:0, generation:0,
    state:'connecting', openedAt:0, receivedAt:0, eventTime:0, retryAt:0,
    catalog:new Map(), catalogOk:false, catalogBusy:false, expected:0}));
  const history = [];
  let totalAlerts = 0, visibleCount = 20, lastLoop = performance.now(), toastTimer = 0;
  let audio = null, soundEnabled = false, lastSound = -Infinity, hiddenAt = null;
  const pct = n => (n > 0 ? '+' : '') + n.toFixed(2) + '%';
  const price = n => Number(n).toLocaleString('en-US', {maximumFractionDigits:Math.abs(n) < 1 ? 10 : Math.abs(n) < 100 ? 6 : 4});
  const timeLabel = n => new Date(n).toLocaleTimeString('vi-VN', {hour12:false});
  const escape = value => String(value).replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  function healthy(feed) { return feed.state === 'live' && performance.now() - feed.receivedAt < 8_000; }
  function syncThreshold() {
    $('threshold').value = engine.threshold;
    $('threshold-slider').value = Math.max(2, Math.min(10, engine.threshold));
    $('threshold-copy').textContent = '±' + engine.threshold + '%';
    $('alert-empty-copy').textContent = `Chờ coin tăng hoặc giảm ít nhất ${engine.threshold}% trong 30 giây.`;
    document.querySelectorAll('[data-threshold]').forEach(b => b.setAttribute('aria-pressed', String(Number(b.dataset.threshold) === engine.threshold)));
    $('threshold-error').hidden = true;
    $('threshold').removeAttribute('aria-invalid');
  }
  function changeThreshold(value) {
    try {
      if (String(value).trim() === '') throw new RangeError('Nhập ngưỡng từ 0,1% đến 100%.');
      engine.setThreshold(Number(String(value).replace(',', '.')));
      try { localStorage.setItem(STORAGE_KEY, String(engine.threshold)); } catch (_) {}
      syncThreshold(); evaluateAll(); render();
      return {threshold:engine.threshold, windowSeconds:30};
    } catch (error) {
      $('threshold-error').textContent = error.message;
      $('threshold-error').hidden = false;
      $('threshold').setAttribute('aria-invalid', 'true');
      throw error;
    }
  }
  function applyThreshold(value) { try { changeThreshold(value); } catch (_) {} }
  $('threshold').addEventListener('change', event => applyThreshold(event.target.value));
  $('threshold').addEventListener('keydown', event => { if(event.key === 'Enter') event.target.blur(); });
  $('threshold-slider').addEventListener('input', event => applyThreshold(event.target.value));
  document.querySelectorAll('[data-threshold]').forEach(button => button.addEventListener('click', () => applyThreshold(button.dataset.threshold)));
  $('show-more').addEventListener('click', () => { visibleCount += 50; render(); });
  $('reconnect').addEventListener('click', () => { for(const feed of feeds) { start(feed, true); loadCatalog(feed); } render(); });
  async function loadCatalog(feed) {
    if (feed.catalogBusy) return;
    feed.catalogBusy = true;
    const controller = new AbortController(), timeout = setTimeout(() => controller.abort(), 12_000);
    try {
      const response = await fetch(feed.rest, {signal:controller.signal, cache:'no-store', credentials:'omit'});
      if (!response.ok) throw new Error('Không tải được danh mục.');
      const payload = await response.json();
      if (!Array.isArray(payload.symbols)) throw new Error('Danh mục không hợp lệ.');
      const next = new Map();
      for (const item of payload.symbols) {
        if (!validSymbol(item.symbol) || marketOf(item, feed.market) !== feed.market) continue;
        const state = item.status || item.contractStatus;
        next.set(item.symbol, {active:state === 'TRADING', base:item.baseAsset,
          quote:item.quoteAsset, type:item.contractType});
      }
      if (!next.size) throw new Error('Danh mục trống.');
      feed.catalog = next;
      feed.expected = [...next.values()].filter(item => item.active).length;
      feed.catalogOk = true;
      for(const row of engine.rows.values()) if (row.market === feed.market && next.get(row.symbol)?.active === false) engine.remove(row.key);
    } catch (_) { feed.catalogOk = false; }
    finally { clearTimeout(timeout); feed.catalogBusy = false; render(); }
  }
  function start(feed, manual = false) {
    clearTimeout(feed.timer);
    const old = feed.ws;
    feed.ws = null; feed.generation++;
    if(old) { old.onclose = null; old.onmessage = null; old.onerror = null; old.close(); }
    engine.resetMarket(feed.market);
    feed.receivedAt = 0; feed.eventTime = 0; feed.openedAt = performance.now(); feed.state = 'connecting';
    if(manual) feed.failures = 0;
    const generation = feed.generation, endpoint = feed.endpoints[feed.index];
    let ws;
    try { ws = new WebSocket(endpoint.url); } catch (_) { retry(feed, generation); return; }
    feed.ws = ws;
    ws.onmessage = event => {
      if(generation !== feed.generation) return;
      let payload;
      try { payload = JSON.parse(event.data); } catch (_) { return; }
      const ticks = Array.isArray(payload) ? payload : payload.data;
      if(!Array.isArray(ticks)) return;
      // A packet may arrive before the watchdog after a network/scheduler gap.
      // Never bridge such a gap with old samples and produce a false alert.
      if((feed.receivedAt && performance.now()-feed.receivedAt>=8000) || performance.now()-lastLoop>5000) {
        engine.resetMarket(feed.market);
        feed.eventTime=0;
      }
      let newest = 0;
      for(const tick of ticks) {
        if(!tick || marketOf(tick, endpoint.fallback) !== feed.market || !validSymbol(tick.s)) continue;
        if(feed.catalog.get(tick.s)?.active === false) continue;
        if(engine.ingest(tick, endpoint.fallback)) newest = Math.max(newest, Number(tick.E));
      }
      if(newest > 0 && newest >= feed.eventTime) {
        feed.eventTime = newest;
        feed.receivedAt = performance.now(); feed.state = 'live'; feed.failures = 0;
        handleAlerts(engine.evaluate(feed.market, newest, true));
      }
    };
    ws.onerror = () => { if(generation === feed.generation) retry(feed, generation); };
    ws.onclose = () => { if(generation === feed.generation) retry(feed, generation); };
  }
  function retry(feed, generation) {
    if(generation !== feed.generation) return;
    feed.generation++;
    if(feed.ws) { feed.ws.onclose=null; feed.ws.onmessage=null; feed.ws.onerror=null; feed.ws.close(); feed.ws=null; }
    engine.resetMarket(feed.market); feed.receivedAt=0; feed.eventTime=0;
    feed.state='retrying'; feed.failures++;
    feed.index = (feed.index + 1) % feed.endpoints.length;
    const delay = Math.min(30_000, 1500 * 2 ** Math.min(feed.failures - 1, 5)) + Math.random() * 700;
    feed.retryAt = performance.now() + delay;
    clearTimeout(feed.timer); feed.timer = setTimeout(() => start(feed), delay);
    render();
  }
  function evaluateAll() {
    for(const feed of feeds) {
      const ok=healthy(feed);
      const now=feed.eventTime + (performance.now() - feed.receivedAt);
      handleAlerts(engine.evaluate(feed.market, now, ok));
    }
  }
  function handleAlerts(alerts) {
    if(!alerts.length) return;
    const received = Date.now();
    for(const item of alerts) { history.unshift({...item, received}); totalAlerts++; }
    history.splice(100);
    renderAlerts(alerts.length);
    const latest = history[0], down = latest.pct < 0;
    $('toast-region').innerHTML = `<div class="toast ${down?'negative':''}"><strong class="${down?'down':'up'}">${escape(latest.symbol)} ${pct(latest.pct)}</strong><span>${names[latest.market]} · trong 30 giây${alerts.length>1?` · +${alerts.length-1} cảnh báo khác`:''}</span></div>`;
    clearTimeout(toastTimer); toastTimer=setTimeout(()=>{ $('toast-region').textContent=''; },8000);
    playSound(down);
  }
  function playSound(down=false, force=false) {
    if(!audio || !soundEnabled || (!force && performance.now()-lastSound<3000)) return;
    if(audio.state !== 'running') { $('sound-message').textContent='Âm thanh đang tạm dừng. Tắt rồi bật lại để kích hoạt.'; return; }
    lastSound=performance.now();
    try {
      const oscillator=audio.createOscillator(), gain=audio.createGain(), now=audio.currentTime;
      oscillator.type='sine'; oscillator.frequency.setValueAtTime(down?520:760,now);
      oscillator.frequency.setValueAtTime(down?380:980,now+.13);
      gain.gain.setValueAtTime(.001,now); gain.gain.exponentialRampToValueAtTime(.13,now+.015);
      gain.gain.exponentialRampToValueAtTime(.001,now+.34);
      oscillator.connect(gain); gain.connect(audio.destination); oscillator.start(now); oscillator.stop(now+.35);
      oscillator.onended=()=>{oscillator.disconnect();gain.disconnect();};
    } catch (_) { $('sound-message').textContent='Không phát được âm thanh trên trình duyệt này.'; }
  }
  $('sound-toggle').addEventListener('click', async () => {
    const button=$('sound-toggle'); button.disabled=true;
    try {
      if(soundEnabled) soundEnabled=false;
      else {
        const Audio=window.AudioContext||window.webkitAudioContext;
        if(!Audio) throw new Error('Trình duyệt này không hỗ trợ âm thanh.');
        audio=audio||new Audio(); await audio.resume();
        if(audio.state!=='running') throw new Error('Chưa bật được âm thanh. Hãy thử lại.');
        soundEnabled=true; playSound(false,true);
      }
      $('sound-message').textContent='';
    } catch(error) {soundEnabled=false;$('sound-message').textContent=error.message;}
    button.setAttribute('aria-pressed',String(soundEnabled));
    $('sound-label').textContent=soundEnabled?'Âm thanh đang bật':'Bật âm thanh'; button.disabled=false;
  });
  function renderAlerts(fresh=0) {
    $('alerts-empty').hidden=history.length>0;
    $('alert-badge').textContent=totalAlerts;
    $('alert-feed').innerHTML=history.map((a,index)=>`<article class="alert-card ${a.pct<0?'negative':''} ${index<fresh?'fresh':''}"><div class="alert-card-top"><strong>${escape(a.symbol)}</strong><b class="${a.pct<0?'down':'up'}">${pct(a.pct)}</b></div><div class="alert-card-details"><span>${names[a.market]} · ngưỡng ±${a.threshold}%</span><time>${timeLabel(a.received)}</time></div><p class="alert-prices">${price(a.base)} → ${price(a.price)}</p></article>`).join('');
    if(fresh) $('alert-feed').scrollTop=0;
  }
  function sparkline(row) {
    const samples=row.samples, n=samples.length;
    if(n<2) return '<span class="neutral">—</span>';
    const values=samples.filter((_,i)=>i%Math.max(1,Math.floor(n/32))===0 || i===n-1).map(s=>s.price);
    const min=Math.min(...values), span=Math.max(...values)-min || 1;
    const points=values.map((v,i)=>`${(i/(values.length-1)*72+1).toFixed(1)},${(25-(v-min)/span*22).toFixed(1)}`).join(' ');
    return `<svg class="sparkline ${row.pct===null?'neutral':row.pct<0?'down':'up'}" viewBox="0 0 74 29" aria-hidden="true"><polyline points="${points}" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/></svg>`;
  }
  function render() {
    const connected=feeds.filter(healthy), rows=[...engine.rows.values()];
    rows.sort((a,b)=>Number(b.ready)-Number(a.ready)||(Math.abs(b.pct||0)-Math.abs(a.pct||0))||a.symbol.localeCompare(b.symbol));
    const ready=rows.filter(r=>r.ready), active=ready.filter(r=>Math.abs(r.pct)+1e-8>=engine.threshold);
    $('clock').textContent=timeLabel(Date.now());
    $('stat-contracts').textContent=rows.length||'—';
    $('stat-ready').textContent=ready.length;
    $('stat-active').textContent=active.length;
    $('stat-alerts').textContent=totalAlerts;
    $('last-alert-copy').textContent=history.length?'Gần nhất '+timeLabel(history[0].received):'Chưa có cảnh báo';
    $('warming-copy').textContent=rows.length>ready.length?`${rows.length-ready.length} hợp đồng đang tích lũy`:ready.length?'Sẵn sàng phát hiện biến động':'Đang thu thập dữ liệu';
    const verified=feeds.every(f=>f.catalogOk), expected=feeds.reduce((s,f)=>s+f.expected,0);
    $('coverage').textContent=verified?`${expected} hợp đồng đang giao dịch`:'USDⓈ-M + COIN-M · chờ danh mục';
    const overall=$('overall-state');
    overall.className='live-state '+(connected.length===2?'live':connected.length===0?'offline':'');
    overall.querySelector('span').textContent=connected.length===2?'Đang nhận dữ liệu':connected.length===1?'Kết nối một phần':'Chưa nhận được dữ liệu';
    const notice=$('connection-notice');
    notice.hidden=connected.length===2&&verified&&ready.length>0;
    if(connected.length<2) {
      const missing=feeds.filter(f=>!healthy(f)).map(f=>names[f.market]).join(', ');
      notice.textContent=`${missing}: chưa nhận được dữ liệu. Đang tự kết nối lại; kiểm tra mạng nếu tình trạng kéo dài. Chỉ các nguồn đã kết nối mới được quét.`;
    } else if(!verified) {
      notice.textContent='Luồng giá đang chạy. Chưa xác minh được đầy đủ danh mục hợp đồng; hiện chỉ quét các mã đã nhận từ Binance.';
    } else if(!ready.length) {
      notice.textContent='Đã kết nối Binance. Đang tích lũy đủ 30 giây dữ liệu để bắt đầu tính biến động.';
    }
    for(const feed of feeds) {
      const element=$('status-'+feed.market), ok=healthy(feed);
      const observed=rows.filter(r=>r.market===feed.market).length;
      element.className=ok?'connected':feed.state==='retrying'?'failed':'';
      element.textContent=names[feed.market]+' · '+(ok?`${observed}${feed.catalogOk?'/'+feed.expected:''} mã`:(feed.state==='retrying'?`thử lại ${Math.max(1,Math.ceil((feed.retryAt-performance.now())/1000))}s`:'đang kết nối'));
    }
    $('table-count').textContent=rows.length+' hợp đồng';
    $('market-empty').hidden=rows.length>0;
    $('market-rows').innerHTML=rows.slice(0,visibleCount).map(row=>{
      const isActive=row.ready&&Math.abs(row.pct)+1e-8>=engine.threshold;
      const feed=feeds.find(f=>f.market===row.market), meta=feed.catalog.get(row.symbol);
      const label=names[row.market]+(meta?.type?(meta.type==='PERPETUAL'?' · Vĩnh cửu':' · Có kỳ hạn'):'');
      return `<tr class="${isActive?(row.pct<0?'alert-down':'alert-up'):''}"><td><span class="symbol">${escape(row.symbol)}</span><span class="market-name">${label}</span></td><td class="price-cell">${price(row.price)}</td><td>${row.ready?`<span class="change ${row.pct<0?'down':row.pct>0?'up':'neutral'}">${pct(row.pct)}</span>`:`<span class="warmup">${Math.floor(row.progress*30)}/30s</span>`}</td><td class="trend-cell">${sparkline(row)}</td></tr>`;
    }).join('');
    $('show-more').hidden=rows.length<=visibleCount;
    $('table-note').textContent=rows.length?`Hiển thị ${Math.min(rows.length,visibleCount)}/${rows.length} · Quét tất cả mã có dữ liệu.`:'Theo dõi toàn bộ hợp đồng đang giao dịch.';
  }
  function tick() {
    const now=performance.now();
    if(now-lastLoop>5000) for(const feed of feeds) start(feed,true);
    lastLoop=now;
    for(const feed of feeds) {
      if(feed.state==='connecting'&&now-feed.openedAt>12000) retry(feed,feed.generation);
      else if(feed.state==='live'&&!healthy(feed)) retry(feed,feed.generation);
    }
    evaluateAll(); render();
  }
  document.addEventListener('visibilitychange',()=>{
    if(document.hidden) hiddenAt=performance.now();
    else {
      if(hiddenAt!==null&&performance.now()-hiddenAt>5000) for(const feed of feeds) start(feed,true);
      hiddenAt=null; lastLoop=performance.now(); render();
    }
  });
  window.addEventListener('online',()=>{for(const feed of feeds){start(feed,true);loadCatalog(feed);}});
  window.addEventListener('offline',()=>{for(const feed of feeds)retry(feed,feed.generation);});
  window.addEventListener('pageshow',event=>{if(event.persisted)for(const feed of feeds)start(feed,true);});
  function registerTools() {
    const context=document.modelContext;
    if(!context?.registerTool) return;
    const lifecycle=new AbortController();
    const register=tool=>{try{Promise.resolve(context.registerTool(tool,{signal:lifecycle.signal})).catch(()=>{});}catch(_){}};
    register({name:'configure_alert_threshold',title:'Đổi ngưỡng cảnh báo',description:'Đổi ngưỡng tăng và giảm của Futures Radar. Có hiệu lực ngay và có thể phát cảnh báo từ dữ liệu hiện tại.',inputSchema:{type:'object',properties:{percent:{type:'number',minimum:0.1,maximum:100}},required:['percent'],additionalProperties:false},annotations:{readOnlyHint:false,untrustedContentHint:false},execute(input){if(!input||typeof input.percent!=='number'||Object.keys(input).some(k=>k!=='percent'))throw new Error('Cần giá trị percent dạng số.');return changeThreshold(input.percent);}});
    register({name:'read_radar_status',title:'Đọc trạng thái theo dõi',description:'Đọc kết nối, ngưỡng cảnh báo và cảnh báo mới nhất của phiên đang mở.',inputSchema:{type:'object',properties:{},additionalProperties:false},annotations:{readOnlyHint:true,untrustedContentHint:true},execute(){return {threshold:engine.threshold,windowSeconds:30,feeds:feeds.map(f=>({market:names[f.market],connected:healthy(f),catalogVerified:f.catalogOk})),symbolsObserved:engine.rows.size,recentAlerts:history.slice(0,10)};}});
    window.addEventListener('pagehide',()=>lifecycle.abort(),{once:true});
  }
  syncThreshold(); render(); renderAlerts();
  for(const feed of feeds){start(feed);loadCatalog(feed);}
  setInterval(tick,1000);
  setInterval(()=>feeds.forEach(loadCatalog),10*60*1000);
  registerTools();
})();
