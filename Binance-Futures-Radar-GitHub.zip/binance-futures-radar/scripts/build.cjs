const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
let html = fs.readFileSync(path.join(root, 'src/index.html'), 'utf8');
for (const [marker, file] of [['/* STYLES */','styles.css'],['/* ENGINE */','engine.js'],['/* APP */','app.js']]) {
  html = html.replace(marker, () => fs.readFileSync(path.join(root, 'src', file), 'utf8'));
}
fs.mkdirSync(path.join(root, 'docs'), {recursive:true});
fs.writeFileSync(path.join(root, 'docs/index.html'), html);
fs.writeFileSync(path.join(root, 'docs/.nojekyll'), '');
console.log('Built docs/index.html — ' + Buffer.byteLength(html) + ' bytes; no external dependencies.');
