const {test} = require('node:test');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname,'..');

function harness() {
  let now = 0;
  class Element {
    constructor(){this.attrs={};this.listeners={};this.textContent='';this.innerHTML='';this.hidden=false;this.value='';this.dataset={};this.className='';}
    setAttribute(k,v){this.attrs[k]=v;}
    removeAttribute(k){delete this.attrs[k];}
    addEventListener(k,fn){this.listeners[k]=fn;}
    querySelector(){return this.child||(this.child=new Element());}
  }
  const ids=[...fs.readFileSync(path.join(root,'src/index.html'),'utf8').matchAll(/id="([^"]+)"/g)].map(m=>m[1]);
  const elements=Object.fromEntries(ids.map(id=>[id,new Element()]));
  const presets=[2,5,10].map(n=>{const e=new Element();e.dataset.threshold=String(n);return e;});
  const tools = new Map(), intervals=[], sockets=[], timers=new Map();
  let timerId=0;
  class Socket {
    constructor(url){this.url=url;sockets.push(this);}
    close(){this.closed=true;}
    sendTicks(ticks){this.onmessage?.({data:JSON.stringify(ticks)});}
  }
  const document={getElementById:id=>elements[id],querySelectorAll:()=>presets,addEventListener(){},hidden:false,
    modelContext:{registerTool(tool){tools.set(tool.name,tool);}}};
  const window={addEventListener(){}};
  const sandbox={document,window,localStorage:{getItem(){return null;},setItem(){}},performance:{now:()=>now},
    WebSocket:Socket,AbortController,console,Date,Intl,
    setTimeout(fn){const id=++timerId;timers.set(id,fn);return id;},clearTimeout(id){timers.delete(id);},
    setInterval(fn){intervals.push(fn);},
    fetch:async url=>({ok:true,json:async()=>({symbols:[{symbol:url.includes('dapi')?'BTCUSD_PERP':'BTCUSDT',status:'TRADING',contractType:'PERPETUAL'}]})})};
  vm.createContext(sandbox);
  for(const file of ['engine.js','app.js'])vm.runInContext(fs.readFileSync(path.join(root,'src',file),'utf8'),sandbox,{filename:file});
  return {elements,tools,sockets,intervals,setTime:t=>{now=t;},now:()=>now,presets};
}
const packet=(time,price,symbol='BTCUSDT',st=1)=>({E:100000+time,c:String(price),s:symbol,st});

test('app consumes both markets, sorts true 30s changes, alerts and validates controls',async()=>{
  const h=harness();
  await new Promise(resolve=>setImmediate(resolve));
  for(let t=0;t<=30000;t+=1000){
    h.setTime(t);
    h.sockets[0].sendTicks([packet(t,t===30000?103:100)]);
    h.sockets[1].sendTicks([packet(t,t===30000?96:100,'BTCUSD_PERP',2)]);
    h.intervals[0]();
  }
  assert.equal(h.elements['stat-ready'].textContent,2);
  assert.equal(h.elements['stat-active'].textContent,2);
  assert.equal(h.elements['stat-alerts'].textContent,2);
  assert.match(h.elements['market-rows'].innerHTML,/-4.00%/);
  assert.ok(h.elements['market-rows'].innerHTML.indexOf('BTCUSD_PERP')<h.elements['market-rows'].innerHTML.indexOf('BTCUSDT'));
  assert.match(h.elements['toast-region'].innerHTML,/BTCUSD_PERP/);
  const tool=h.tools.get('configure_alert_threshold');
  assert.equal(tool.execute({percent:5}).threshold,5);
  assert.equal(h.elements['stat-active'].textContent,0);
  assert.equal(h.elements.threshold.value,5);
  assert.throws(()=>tool.execute({percent:0}));
  assert.equal(h.tools.get('read_radar_status').execute().threshold,5);
  h.presets[0].listeners.click();
  assert.equal(h.tools.get('read_radar_status').execute().threshold,2);
  assert.equal(h.elements['stat-active'].textContent,2);
});

test('network gap before watchdog cannot bridge old prices; reconnect clears live values',async()=>{
  const h=harness();await new Promise(resolve=>setImmediate(resolve));
  for(let t=0;t<=30000;t+=1000){h.setTime(t);h.sockets[0].sendTicks([packet(t,100)]);h.intervals[0]();}
  h.setTime(41000);h.sockets[0].sendTicks([packet(41000,140)]);
  assert.equal(h.tools.get('read_radar_status').execute().recentAlerts.length,0);
  h.intervals[0]();
  assert.equal(h.elements['stat-ready'].textContent,0);
  assert.equal(h.elements['stat-active'].textContent,0);
  h.elements.reconnect.listeners.click();
  assert.equal(h.tools.get('read_radar_status').execute().symbolsObserved,0);
});
