const {test} = require('node:test');
const assert = require('node:assert/strict');
const {RadarEngine, marketOf} = require('../src/engine.js');
const tick = (E,c,s='BTCUSDT',st=1) => ({E,c:String(c),s,st});
function seed(engine, price=100, end=29000, symbol='BTCUSDT', st=1) {
  for(let t=0;t<=end;t+=1000) engine.ingest(tick(t,price,symbol,st),'UM');
}
test('requires a full 30-second window, then detects an exact +2% crossing',()=>{
  const e=new RadarEngine(2); seed(e);
  e.ingest(tick(29999,102),'UM'); assert.equal(e.evaluate('UM',29999).length,0);
  e.ingest(tick(30000,102),'UM'); const a=e.evaluate('UM',30000);
  assert.equal(a.length,1); assert.equal(a[0].pct,2); assert.equal(a[0].base,100);
});
test('detects negative moves and does not cap alerts at 10%',()=>{
  const e=new RadarEngine(2); seed(e); e.ingest(tick(30000,88),'UM');
  assert.equal(e.evaluate('UM',30000)[0].pct,-12);
});
test('uses the last price at or before 30s ago, never the next observation',()=>{
  const e=new RadarEngine(2);
  e.ingest(tick(0,100),'UM'); e.ingest(tick(1200,110),'UM');
  e.ingest(tick(30500,103),'UM'); const a=e.evaluate('UM',30500);
  assert.equal(a[0].base,100); assert.equal(a[0].pct,3);
});
test('unchanged symbols omitted from delta arrays keep their last observed price',()=>{
  const e=new RadarEngine(2); e.ingest(tick(0,100),'UM');
  e.ingest(tick(35000,103),'UM'); assert.equal(e.evaluate('UM',35000)[0].pct,3);
  assert.equal(e.evaluate('UM',65000).length,0);
  assert.equal(e.rows.get('UM:BTCUSDT').pct,0);
});
test('does not repeatedly notify while above threshold; re-arms below 80%',()=>{
  const e=new RadarEngine(2); seed(e); e.ingest(tick(30000,102),'UM');
  assert.equal(e.evaluate('UM',30000).length,1);
  e.ingest(tick(31000,103),'UM'); assert.equal(e.evaluate('UM',31000).length,0);
  e.ingest(tick(32000,101.9),'UM'); e.evaluate('UM',32000);
  e.ingest(tick(33000,102.1),'UM'); assert.equal(e.evaluate('UM',33000).length,0);
  e.ingest(tick(34000,101),'UM'); e.evaluate('UM',34000);
  e.ingest(tick(35000,102.1),'UM'); assert.equal(e.evaluate('UM',35000).length,1);
});
test('opposite direction can alert immediately and threshold edits apply',()=>{
  const e=new RadarEngine(2); seed(e); e.ingest(tick(30000,102),'UM'); e.evaluate('UM',30000);
  e.ingest(tick(31000,97),'UM'); assert.equal(e.evaluate('UM',31000)[0].pct,-3);
  e.setThreshold(5); assert.equal(e.evaluate('UM',31000).length,0);
  e.setThreshold(2.5); assert.equal(e.evaluate('UM',31000).length,1);
});
test('invalid and old packets cannot rewrite price or create alerts',()=>{
  const e=new RadarEngine(); e.ingest(tick(1000,100),'UM');
  for(const t of [tick(0,110),tick(1000,110),tick(2000,NaN),tick(2000,0),tick(2000,Infinity),tick(2000,101,'<script>')]) assert.equal(e.ingest(t,'UM'),false);
  assert.equal(e.rows.size,1); assert.equal(e.rows.get('UM:BTCUSDT').price,100);
});
test('st routes merged universe correctly and markets remain isolated',()=>{
  const e=new RadarEngine(); seed(e); seed(e,100,29000,'BTCUSD_PERP',2);
  assert.equal(marketOf({st:2},'UM'),'CM'); assert.equal(marketOf({},'UM'),'UM');
  e.ingest(tick(30000,103),'UM'); e.ingest(tick(30000,97,'BTCUSD_PERP',2),'UM');
  assert.equal(e.evaluate('UM',30000)[0].pct,3); assert.equal(e.evaluate('CM',30000)[0].pct,-3);
});
test('stale sources do not alert and reconnect requires a new window',()=>{
  const e=new RadarEngine(); seed(e); e.ingest(tick(30000,103),'UM');
  assert.equal(e.evaluate('UM',30000,false).length,0); assert.equal(e.rows.get('UM:BTCUSDT').pct,null);
  e.resetMarket('UM'); e.ingest(tick(50000,104),'UM');
  assert.equal(e.evaluate('UM',50000).length,0); assert.equal(e.rows.get('UM:BTCUSDT').ready,false);
});
test('rejects invalid thresholds and bounds retained samples',()=>{
  const e=new RadarEngine(); for(const v of [0,-1,NaN,Infinity,101,'abc'])assert.throws(()=>e.setThreshold(v),RangeError);
  e.setThreshold(.1); seed(e,100,300000);
  assert.ok(e.rows.get('UM:BTCUSDT').samples.length<=31);
});
