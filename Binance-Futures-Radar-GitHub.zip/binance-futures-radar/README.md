# Futures Radar

Trang theo dõi Binance Futures bằng tiếng Việt, dùng trực tiếp dữ liệu công khai từ Binance. Không cần API key hoặc tài khoản Binance.

## Sử dụng

- Theo dõi USDⓈ-M và COIN-M, gồm hợp đồng vĩnh cửu và có kỳ hạn đang giao dịch.
- Mặc định báo khi giá tăng hoặc giảm từ **2% trong 30 giây**. Chọn nhanh 2%, 5%, 10%; kéo thanh 2–10%; hoặc nhập ngưỡng 0,1–100%.
- **2–10% là phạm vi chỉnh nhanh, không phải giới hạn trên của cảnh báo.** Biến động vượt 10% vẫn được báo.
- Mã vượt ngưỡng được làm nổi bật. Bảng giá xếp theo độ lớn biến động; cảnh báo mới ở đầu cột cảnh báo, kèm thông báo nổi và âm thanh nếu bật.
- Chờ tối thiểu 30 giây sau khi giá đầu tiên của từng mã được nhận. Sau khi mất kết nối hoặc quay lại trang đã bị tạm dừng, cửa sổ được xây dựng lại.
- Giữ trang mở. Điện thoại có thể tạm dừng trang khi khóa màn hình hoặc chuyển ứng dụng. Trang tĩnh không thể chạy giám sát phía máy chủ 24/7 hay gửi cảnh báo khi đã đóng trang.
- Cài đặt ngưỡng lưu trên thiết bị. Cảnh báo lưu tối đa 100 mục trong phiên mở trang; tải lại sẽ xóa lịch sử. Âm thanh cần bấm bật mỗi phiên.

## Cách tính

`thay đổi (%) = (giá hiện tại − giá quan sát tại mốc 30 giây trước) / giá quan sát tại mốc đó × 100`

Dùng `c` (giá giao dịch gần nhất) và `E` (thời điểm sự kiện) từ `!miniTicker@arr`, không dùng tỷ lệ biến động 24 giờ. Mốc đầu là giá nhận cuối cùng tại hoặc trước `E − 30.000 ms`. Binance chỉ gửi các ticker có cập nhật, nên giữ giá quan sát cuối cùng khi một mã không nằm trong gói mới. Khi kết nối toàn thị trường mất hoặc im lặng quá 8 giây, bỏ dữ liệu của nguồn đó và kết nối lại.

Nguồn cập nhật khoảng một lần mỗi giây; đây không phải luồng ghi lại từng giao dịch, vì vậy có thể bỏ lỡ biến động rất ngắn giữa hai lần cập nhật. Thời gian nhận có thể chậm do mạng. Danh mục được tải từ `exchangeInfo` và làm mới mỗi 10 phút. Nếu tải danh mục thất bại, giao diện ghi rõ phạm vi chưa được xác minh; vẫn quét các mã nhận được từ luồng.

Ngăn lặp cảnh báo: mỗi chiều chỉ báo một lần khi vượt ngưỡng, kích hoạt lại khi độ lớn xuống dưới 80% ngưỡng, đảo chiều vượt ngưỡng hoặc ngưỡng được thay đổi.

## Đưa lên GitHub Pages

Trang xuất bản là **`docs/index.html`**, đã chứa toàn bộ CSS và JavaScript, không cần cài thêm thư viện.

1. Tạo một repository mới và đưa các tệp trong dự án lên nhánh `main`.
2. Trong repository, mở **Settings → Pages**.
3. Ở **Build and deployment**, chọn **Deploy from a branch**.
4. Chọn nhánh **main**, thư mục **/docs**, rồi **Save**.
5. Chờ GitHub Pages triển khai xong. Mở URL do mục Pages hiển thị.

Với GitHub Free, dùng repository public để xuất bản Pages. Không đưa khóa API hay thông tin riêng tư vào repository. Dự án này không có khóa API.

Nếu chỉ muốn tải lên một tệp, dùng `docs/index.html`, đặt nó ở gốc repository và chọn **/(root)** trong bước 4.

## Chỉnh sửa mã nguồn

Yêu cầu Node.js có trình kiểm thử tích hợp, không cần `npm install`.

```sh
npm test
npm run build
```

Sửa trong `src/`, chạy build, commit cả mã nguồn và `docs/index.html`. `scripts/build.cjs` ghép các tệp thành trang HTML độc lập. Thư mục `test/` kiểm tra phép tính cửa sổ trượt, tăng/giảm, ngăn lặp, dữ liệu cũ và khởi động lại sau gián đoạn.

## Nguồn chính thức

- [Binance Futures WebSocket market streams](https://developers.binance.com/en/docs/catalog/core-trading-derivatives-trading-usd-s-m-futures/api/ws-streams/market)
- [Binance Futures exchange information](https://developers.binance.com/en/docs/catalog/core-trading-derivatives-trading-usd-s-m-futures/api/rest-api/market-data)
- [GitHub Pages quickstart](https://docs.github.com/en/pages/quickstart)

Hỗ trợ điểm kết nối Futures mới có `/market/ws/` và điểm kết nối cũ `/ws/`; dùng trường `st` nếu có để tách USDⓈ-M khỏi COIN-M trong luồng đã hợp nhất.
